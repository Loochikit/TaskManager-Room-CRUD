// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("com.android.application") version "9.0.0-alpha06" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}